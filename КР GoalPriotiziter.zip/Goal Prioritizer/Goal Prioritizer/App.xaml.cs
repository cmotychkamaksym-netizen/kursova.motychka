using System.Windows;
using Goal_Prioritizer.Services;
using Goal_Prioritizer.ViewModels;
using Goal_Prioritizer.Views;

namespace Goal_Prioritizer
{
    public partial class App : Application
    {
        private JsonStorageService? _storageService;
        private AuthService? _authService;
        private GoalService? _goalService;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _storageService = new JsonStorageService();
            _authService = new AuthService(_storageService);
            _goalService = new GoalService(_storageService);

            ShowLoginWindow();
        }

        public void ShowLoginWindow()
        {
            if (_authService == null || _goalService == null) return;

            var loginVm = new LoginViewModel(_authService);
            var loginWindow = new LoginWindow { DataContext = loginVm };

            loginVm.OnLoginSuccess += (user) =>
            {
                var mainVm = new MainViewModel(user, _goalService);
                var mainWindow = new MainWindow { DataContext = mainVm };

                mainVm.OnLogout += () =>
                {
                    mainWindow.Close();
                    ShowLoginWindow();
                };

                loginWindow.Close();
                mainWindow.Show();
            };

            loginVm.OnOpenRegister += () =>
            {
                var registerVm = new RegisterViewModel(_authService);
                var registerWindow = new RegisterWindow { DataContext = registerVm, Owner = loginWindow };

                registerVm.OnRegisterSuccess += () =>
                {
                    registerWindow.Close();
                };

                registerVm.OnBackToLogin += () =>
                {
                    registerWindow.Close();
                };

                registerWindow.ShowDialog();
            };

            loginWindow.Show();
        }
    }
}
