using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Goal_Prioritizer.Models;

namespace Goal_Prioritizer.Converters
{
    public class PriorityToForegroundBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is PriorityLevel priority)
            {
                return priority switch
                {
                    PriorityLevel.High => (SolidColorBrush)new BrushConverter().ConvertFrom("#F38BA8")!,   // Red
                    PriorityLevel.Medium => (SolidColorBrush)new BrushConverter().ConvertFrom("#FAB387")!, // Orange
                    PriorityLevel.Low => (SolidColorBrush)new BrushConverter().ConvertFrom("#F9E2AF")!,    // Yellow
                    _ => (SolidColorBrush)new BrushConverter().ConvertFrom("#CDD6F4")!
                };
            }
            return (SolidColorBrush)new BrushConverter().ConvertFrom("#CDD6F4")!;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class PriorityToBackgroundBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is PriorityLevel priority)
            {
                return priority switch
                {
                    PriorityLevel.High => (SolidColorBrush)new BrushConverter().ConvertFrom("#3D1E28")!,   // Dark Red Tint
                    PriorityLevel.Medium => (SolidColorBrush)new BrushConverter().ConvertFrom("#3D2E1E")!, // Dark Orange Tint
                    PriorityLevel.Low => (SolidColorBrush)new BrushConverter().ConvertFrom("#3D391E")!,    // Dark Yellow Tint
                    _ => (SolidColorBrush)new BrushConverter().ConvertFrom("#181825")!
                };
            }
            return (SolidColorBrush)new BrushConverter().ConvertFrom("#181825")!;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class PriorityToBorderBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is PriorityLevel priority)
            {
                return priority switch
                {
                    PriorityLevel.High => (SolidColorBrush)new BrushConverter().ConvertFrom("#F38BA8")!,   // Red Border
                    PriorityLevel.Medium => (SolidColorBrush)new BrushConverter().ConvertFrom("#FAB387")!, // Orange Border
                    PriorityLevel.Low => (SolidColorBrush)new BrushConverter().ConvertFrom("#F9E2AF")!,    // Yellow Border
                    _ => (SolidColorBrush)new BrushConverter().ConvertFrom("#45475A")!
                };
            }
            return (SolidColorBrush)new BrushConverter().ConvertFrom("#45475A")!;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
