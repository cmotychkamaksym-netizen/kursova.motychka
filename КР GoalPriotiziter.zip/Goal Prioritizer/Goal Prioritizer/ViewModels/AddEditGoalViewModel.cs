using System;
using System.Collections.Generic;
using System.Windows.Input;
using Goal_Prioritizer.Models;

namespace Goal_Prioritizer.ViewModels
{
    public class AddEditGoalViewModel : ViewModelBase
    {
        private string _title = string.Empty;
        private string _description = string.Empty;
        private PriorityLevel _selectedPriority = PriorityLevel.Medium;
        private DateTime? _targetDate = DateTime.Now.AddDays(7);
        private string _errorMessage = string.Empty;

        public event Action<GoalItem>? OnSave;
        public event Action? OnCancel;

        public GoalItem? ExistingGoal { get; }

        public AddEditGoalViewModel(GoalItem? existingGoal = null)
        {
            ExistingGoal = existingGoal;

            if (existingGoal != null)
            {
                Title = existingGoal.Title;
                Description = existingGoal.Description;
                SelectedPriority = existingGoal.Priority;
                TargetDate = existingGoal.TargetDate;
            }

            SaveCommand = new RelayCommand(ExecuteSave);
            CancelCommand = new RelayCommand(ExecuteCancel);
        }

        public string WindowTitle => ExistingGoal == null ? "Додати нову ціль" : "Редагувати ціль";

        public string Title
        {
            get => _title;
            set => SetField(ref _title, value);
        }

        public string Description
        {
            get => _description;
            set => SetField(ref _description, value);
        }

        public PriorityLevel SelectedPriority
        {
            get => _selectedPriority;
            set => SetField(ref _selectedPriority, value);
        }

        public DateTime? TargetDate
        {
            get => _targetDate;
            set => SetField(ref _targetDate, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetField(ref _errorMessage, value);
        }

        public IEnumerable<PriorityLevel> Priorities => new List<PriorityLevel>
        {
            PriorityLevel.High,
            PriorityLevel.Medium,
            PriorityLevel.Low
        };

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        private void ExecuteSave()
        {
            ErrorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(Title))
            {
                ErrorMessage = "Будь ласка, введіть назву цілі.";
                return;
            }

            GoalItem goal = ExistingGoal ?? new GoalItem();
            goal.Title = Title.Trim();
            goal.Description = Description?.Trim() ?? string.Empty;
            goal.Priority = SelectedPriority;
            goal.TargetDate = TargetDate;

            OnSave?.Invoke(goal);
        }

        private void ExecuteCancel()
        {
            OnCancel?.Invoke();
        }
    }
}
