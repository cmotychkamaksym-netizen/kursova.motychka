using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Goal_Prioritizer.Models;
using Goal_Prioritizer.Services;

namespace Goal_Prioritizer.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly GoalService _goalService;
        private readonly User _currentUser;
        private string _searchQuery = string.Empty;

        public ObservableCollection<GoalItemViewModel> HighPriorityGoals { get; } = new();
        public ObservableCollection<GoalItemViewModel> MediumPriorityGoals { get; } = new();
        public ObservableCollection<GoalItemViewModel> LowPriorityGoals { get; } = new();
        public ObservableCollection<GoalItemViewModel> CompletedGoals { get; } = new();

        public event Action? OnLogout;
        public event Action<AddEditGoalViewModel>? OnOpenAddGoalDialog;
        public event Action<AddEditGoalViewModel>? OnOpenEditGoalDialog;

        public MainViewModel(User currentUser, GoalService goalService)
        {
            _currentUser = currentUser;
            _goalService = goalService;

            AddGoalCommand = new RelayCommand(ExecuteAddGoal);
            AddGoalWithPriorityCommand = new RelayCommand(ExecuteAddGoalWithPriority);
            EditGoalCommand = new RelayCommand(ExecuteEditGoal);
            DeleteGoalCommand = new RelayCommand(ExecuteDeleteGoal);
            LogoutCommand = new RelayCommand(ExecuteLogout);

            LoadGoals();
        }

        public User CurrentUser => _currentUser;
        public string WelcomeMessage => $"Вітаємо, {_currentUser.Username}!";

        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                if (SetField(ref _searchQuery, value))
                {
                    ApplyFilters();
                }
            }
        }

        public ICommand AddGoalCommand { get; }
        public ICommand AddGoalWithPriorityCommand { get; }
        public ICommand EditGoalCommand { get; }
        public ICommand DeleteGoalCommand { get; }
        public ICommand LogoutCommand { get; }

        public void LoadGoals()
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            var goals = _goalService.GetGoalsForUser(_currentUser.Username);

            // Фільтрація по пошуковому запиту
            if (!string.IsNullOrWhiteSpace(SearchQuery))
            {
                string query = SearchQuery.Trim().ToLower();
                goals = goals.Where(g =>
                    g.Title.ToLower().Contains(query) ||
                    g.Description.ToLower().Contains(query)).ToList();
            }

            var activeGoals = goals.Where(g => !g.IsCompleted).ToList();

            // Оновлюємо колонку Високого пріоритету
            HighPriorityGoals.Clear();
            foreach (var goal in activeGoals.Where(g => g.Priority == PriorityLevel.High).OrderBy(g => g.TargetDate ?? DateTime.MaxValue))
            {
                HighPriorityGoals.Add(CreateGoalItemViewModel(goal));
            }

            // Оновлюємо колонку Середнього пріоритету
            MediumPriorityGoals.Clear();
            foreach (var goal in activeGoals.Where(g => g.Priority == PriorityLevel.Medium).OrderBy(g => g.TargetDate ?? DateTime.MaxValue))
            {
                MediumPriorityGoals.Add(CreateGoalItemViewModel(goal));
            }

            // Оновлюємо колонку Низького пріоритету
            LowPriorityGoals.Clear();
            foreach (var goal in activeGoals.Where(g => g.Priority == PriorityLevel.Low).OrderBy(g => g.TargetDate ?? DateTime.MaxValue))
            {
                LowPriorityGoals.Add(CreateGoalItemViewModel(goal));
            }

            // Оновлюємо виконані цілі (Архів)
            CompletedGoals.Clear();
            var completedItems = goals
                .Where(g => g.IsCompleted)
                .OrderByDescending(g => g.CompletedAt ?? g.CreatedAt);

            foreach (var goal in completedItems)
            {
                CompletedGoals.Add(CreateGoalItemViewModel(goal));
            }
        }

        private GoalItemViewModel CreateGoalItemViewModel(GoalItem item)
        {
            var vm = new GoalItemViewModel(item);
            vm.OnCompletionToggled += (goalId, isCompleted) =>
            {
                _goalService.ToggleGoalCompletion(_currentUser.Username, goalId, isCompleted);
                ApplyFilters(); // Оновлюємо дошки
            };
            return vm;
        }

        private void ExecuteAddGoal()
        {
            ExecuteAddGoalWithPriority(PriorityLevel.Medium);
        }

        private void ExecuteAddGoalWithPriority(object? parameter)
        {
            PriorityLevel priority = PriorityLevel.Medium;

            if (parameter is PriorityLevel p)
            {
                priority = p;
            }
            else if (parameter is string pStr)
            {
                priority = pStr switch
                {
                    "High" or "Високий" => PriorityLevel.High,
                    "Medium" or "Середній" => PriorityLevel.Medium,
                    "Low" or "Низький" => PriorityLevel.Low,
                    _ => PriorityLevel.Medium
                };
            }

            var addVm = new AddEditGoalViewModel { SelectedPriority = priority };
            addVm.OnSave += (newGoal) =>
            {
                newGoal.UserId = _currentUser.Id;
                _goalService.AddGoal(_currentUser.Username, newGoal);
                ApplyFilters();
            };

            OnOpenAddGoalDialog?.Invoke(addVm);
        }

        private void ExecuteEditGoal(object? parameter)
        {
            if (parameter is GoalItemViewModel goalVm)
            {
                var editVm = new AddEditGoalViewModel(goalVm.Model);
                editVm.OnSave += (updatedGoal) =>
                {
                    _goalService.UpdateGoal(_currentUser.Username, updatedGoal);
                    ApplyFilters();
                };

                OnOpenEditGoalDialog?.Invoke(editVm);
            }
        }

        private void ExecuteDeleteGoal(object? parameter)
        {
            if (parameter is GoalItemViewModel goalVm)
            {
                _goalService.DeleteGoal(_currentUser.Username, goalVm.Model.Id);
                ApplyFilters();
            }
        }

        private void ExecuteLogout()
        {
            OnLogout?.Invoke();
        }
    }

    public class GoalItemViewModel : ViewModelBase
    {
        private readonly GoalItem _model;

        public event Action<Guid, bool>? OnCompletionToggled;

        public GoalItemViewModel(GoalItem model)
        {
            _model = model;
        }

        public GoalItem Model => _model;
        public Guid Id => _model.Id;
        public string Title => _model.Title;
        public string Description => _model.Description;
        public PriorityLevel Priority => _model.Priority;
        public string PriorityName => _model.PriorityName;
        public DateTime CreatedAt => _model.CreatedAt;
        public DateTime? TargetDate => _model.TargetDate;
        public DateTime? CompletedAt => _model.CompletedAt;

        public bool IsCompleted
        {
            get => _model.IsCompleted;
            set
            {
                if (_model.IsCompleted != value)
                {
                    _model.IsCompleted = value;
                    OnPropertyChanged();
                    OnCompletionToggled?.Invoke(_model.Id, value);
                }
            }
        }
    }
}
