using System;
using System.Windows.Input;
using Goal_Prioritizer.Models;
using Goal_Prioritizer.Services;

namespace Goal_Prioritizer.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly AuthService _authService;
        private string _usernameOrEmail = string.Empty;
        private string _errorMessage = string.Empty;
        private bool _showRegisterLink = true;

        public event Action<User>? OnLoginSuccess;
        public event Action? OnOpenRegister;

        public LoginViewModel(AuthService authService)
        {
            _authService = authService;
            LoginCommand = new RelayCommand(ExecuteLogin);
            OpenRegisterCommand = new RelayCommand(ExecuteOpenRegister);
        }

        public string UsernameOrEmail
        {
            get => _usernameOrEmail;
            set => SetField(ref _usernameOrEmail, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetField(ref _errorMessage, value);
        }

        public bool ShowRegisterLink
        {
            get => _showRegisterLink;
            set => SetField(ref _showRegisterLink, value);
        }

        public ICommand LoginCommand { get; }
        public ICommand OpenRegisterCommand { get; }

        public void ExecuteLoginWithPassword(string password)
        {
            ErrorMessage = string.Empty;
            // reset register link visibility before attempt
            ShowRegisterLink = true;

            if (_authService.Login(UsernameOrEmail, password, out User? user, out string error))
            {
                if (user != null)
                {
                    OnLoginSuccess?.Invoke(user);
                }
            }
            else
            {
                ErrorMessage = error;
                // Hide "Create account" when specific "user not found" error appears
                if (error == "Користувача з таким логіном або поштою не знайдено.")
                {
                    ShowRegisterLink = false;
                }
                else
                {
                    ShowRegisterLink = true;
                }
            }
        }

        private void ExecuteLogin(object? parameter)
        {
            // У випадку якщо параметр передається з PasswordBox
            if (parameter is string password)
            {
                ExecuteLoginWithPassword(password);
            }
        }

        private void ExecuteOpenRegister()
        {
            OnOpenRegister?.Invoke();
        }
    }
}
