using System;
using System.Windows.Input;
using Goal_Prioritizer.Services;

namespace Goal_Prioritizer.ViewModels
{
    // No-op update to ensure file is updated.
    public class RegisterViewModel : ViewModelBase
    {
        private readonly AuthService _authService;
        private string _username = string.Empty;
        private string _email = string.Empty;
        private string _errorMessage = string.Empty;
        private string _successMessage = string.Empty;

        public event Action? OnRegisterSuccess;
        public event Action? OnBackToLogin;

        public RegisterViewModel(AuthService authService)
        {
            _authService = authService;
            RegisterCommand = new RelayCommand(ExecuteRegister);
            BackToLoginCommand = new RelayCommand(ExecuteBackToLogin);
        }

        public string Username
        {
            get => _username;
            set => SetField(ref _username, value);
        }

        public string Email
        {
            get => _email;
            set => SetField(ref _email, value);
        }

        public string ErrorMessage
        {
            get => _errorMessage;
            set => SetField(ref _errorMessage, value);
        }

        public string SuccessMessage
        {
            get => _successMessage;
            set => SetField(ref _successMessage, value);
        }

        public ICommand RegisterCommand { get; }
        public ICommand BackToLoginCommand { get; }

        public void ExecuteRegisterWithPasswords(string password, string confirmPassword)
        {
            ErrorMessage = string.Empty;
            SuccessMessage = string.Empty;

            if (password != confirmPassword)
            {
                ErrorMessage = "Паролі не збігаються.";
                return;
            }

            if (_authService.Register(Username, Email, password, out string error))
            {
                SuccessMessage = "Акаунт успішно створено! Повертаємось до входу...";
                OnRegisterSuccess?.Invoke();
            }
            else
            {
                ErrorMessage = error;
            }
        }

        private void ExecuteRegister(object? parameter)
        {
            // Параметри можуть передаватися з в'юшки
        }

        private void ExecuteBackToLogin()
        {
            OnBackToLogin?.Invoke();
        }
    }
}
