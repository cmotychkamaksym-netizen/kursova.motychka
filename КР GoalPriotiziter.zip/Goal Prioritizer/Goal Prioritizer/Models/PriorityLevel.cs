namespace Goal_Prioritizer.Models
{
    public enum PriorityLevel
    {
        Low = 0,    // Низький (Жовтий)
        Medium = 1, // Середній (Помаранчевий)
        High = 2    // Високий (Червоний)
    }

    public static class PriorityLevelExtensions
    {
        public static string ToDisplayString(this PriorityLevel priority)
        {
            return priority switch
            {
                PriorityLevel.Low => "Низький",
                PriorityLevel.Medium => "Середній",
                PriorityLevel.High => "Високий",
                _ => "Низький"
            };
        }
    }
}
