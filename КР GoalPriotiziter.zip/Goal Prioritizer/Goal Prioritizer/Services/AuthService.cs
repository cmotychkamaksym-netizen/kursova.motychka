using System;
using System.Collections.Generic;
using System.Linq;
using Goal_Prioritizer.Models;

namespace Goal_Prioritizer.Services
{
    public class AuthService
    {
        private const string UsersFileName = "users.json";
        private readonly JsonStorageService _storageService;

        public AuthService(JsonStorageService storageService)
        {
            _storageService = storageService;
        }

        public bool Register(string username, string email, string password, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(username))
            {
                errorMessage = "Будь ласка, введіть логін.";
                return false;
            }

            if (username.Trim().Length < 3)
            {
                errorMessage = "Логін повинен містити щонайменше 3 символи.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(email) || !email.Contains('@'))
            {
                errorMessage = "Будь ласка, введіть коректне заповнення пошти.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(password) || password.Length < 4)
            {
                errorMessage = "Пароль повинен містити щонайменше 4 символи.";
                return false;
            }

            List<User> users = _storageService.LoadData<User>(UsersFileName);

            if (users.Any(u => u.Username.Equals(username.Trim(), StringComparison.OrdinalIgnoreCase)))
            {
                errorMessage = "Користувач із таким логіном вже існує.";
                return false;
            }

            if (users.Any(u => u.Email.Equals(email.Trim(), StringComparison.OrdinalIgnoreCase)))
            {
                errorMessage = "Користувач із такою електронною поштою вже існує.";
                return false;
            }

            string salt = PasswordHasher.GenerateSalt();
            string passwordHash = PasswordHasher.HashPassword(password, salt);

            User newUser = new User
            {
                Id = Guid.NewGuid(),
                Username = username.Trim(),
                Email = email.Trim(),
                PasswordHash = passwordHash,
                PasswordSalt = salt,
                CreatedAt = DateTime.Now
            };

            users.Add(newUser);
            _storageService.SaveData(UsersFileName, users);

            return true;
        }

        public bool Login(string usernameOrEmail, string password, out User? user, out string errorMessage)
        {
            user = null;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(usernameOrEmail))
            {
                errorMessage = "Будь ласка, введіть логін або пошту.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "Будь ласка, введіть пароль.";
                return false;
            }

            List<User> users = _storageService.LoadData<User>(UsersFileName);

            User? foundUser = users.FirstOrDefault(u =>
                u.Username.Equals(usernameOrEmail.Trim(), StringComparison.OrdinalIgnoreCase) ||
                u.Email.Equals(usernameOrEmail.Trim(), StringComparison.OrdinalIgnoreCase));

            if (foundUser == null)
            {
                errorMessage = "Користувача з таким логіном або поштою не знайдено.";
                return false;
            }

            bool isValidPassword = PasswordHasher.VerifyPassword(password, foundUser.PasswordHash, foundUser.PasswordSalt);
            if (!isValidPassword)
            {
                errorMessage = "Невірний пароль. Спробуйте ще раз.";
                return false;
            }

            user = foundUser;
            return true;
        }
    }
}
