using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Unicode;

namespace Goal_Prioritizer.Services
{
    public class JsonStorageService
    {
        private readonly string _dataDirectory;

        public JsonStorageService()
        {
            // Шлях до папки Data відносно папки виконання програми (.exe)
            _dataDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");
            EnsureDirectoryExists(_dataDirectory);
        }

        private static void EnsureDirectoryExists(string dirPath)
        {
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }
        }

        private static JsonSerializerOptions GetJsonOptions()
        {
            return new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.All) // Підтримка кирилиці без екранування
            };
        }

        public List<T> LoadData<T>(string relativePath)
        {
            string filePath = Path.Combine(_dataDirectory, relativePath);

            if (!File.Exists(filePath))
            {
                return new List<T>();
            }

            try
            {
                string json = File.ReadAllText(filePath);
                if (string.IsNullOrWhiteSpace(json))
                {
                    return new List<T>();
                }
                return JsonSerializer.Deserialize<List<T>>(json, GetJsonOptions()) ?? new List<T>();
            }
            catch
            {
                return new List<T>();
            }
        }

        public void SaveData<T>(string relativePath, List<T> data)
        {
            string filePath = Path.Combine(_dataDirectory, relativePath);
            string? parentDir = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(parentDir))
            {
                EnsureDirectoryExists(parentDir);
            }

            string json = JsonSerializer.Serialize(data, GetJsonOptions());
            File.WriteAllText(filePath, json, System.Text.Encoding.UTF8);
        }
    }
}
