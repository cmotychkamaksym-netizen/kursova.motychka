using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Goal_Prioritizer.Models;

namespace Goal_Prioritizer.Services
{
    public class GoalService
    {
        private readonly JsonStorageService _storageService;

        public GoalService(JsonStorageService storageService)
        {
            _storageService = storageService;
        }

        private static string GetUserGoalsFilePath(string username)
        {
            // Санітизація імені папки користувача
            string safeUsername = string.Concat(username.Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();
            if (string.IsNullOrEmpty(safeUsername)) safeUsername = "default_user";

            // Внутрішній відносний шлях: Goals/{username}/goals.json
            return Path.Combine("Goals", safeUsername, "goals.json");
        }

        public List<GoalItem> GetGoalsForUser(string username)
        {
            string filePath = GetUserGoalsFilePath(username);
            return _storageService.LoadData<GoalItem>(filePath);
        }

        public void AddGoal(string username, GoalItem goal)
        {
            string filePath = GetUserGoalsFilePath(username);
            List<GoalItem> goals = _storageService.LoadData<GoalItem>(filePath);
            goals.Add(goal);
            _storageService.SaveData(filePath, goals);
        }

        public void UpdateGoal(string username, GoalItem updatedGoal)
        {
            string filePath = GetUserGoalsFilePath(username);
            List<GoalItem> goals = _storageService.LoadData<GoalItem>(filePath);
            int index = goals.FindIndex(g => g.Id == updatedGoal.Id);

            if (index != -1)
            {
                goals[index] = updatedGoal;
                _storageService.SaveData(filePath, goals);
            }
        }

        public void ToggleGoalCompletion(string username, Guid goalId, bool isCompleted)
        {
            string filePath = GetUserGoalsFilePath(username);
            List<GoalItem> goals = _storageService.LoadData<GoalItem>(filePath);
            GoalItem? goal = goals.FirstOrDefault(g => g.Id == goalId);

            if (goal != null)
            {
                goal.IsCompleted = isCompleted;
                goal.CompletedAt = isCompleted ? DateTime.Now : null;
                _storageService.SaveData(filePath, goals);
            }
        }

        public void DeleteGoal(string username, Guid goalId)
        {
            string filePath = GetUserGoalsFilePath(username);
            List<GoalItem> goals = _storageService.LoadData<GoalItem>(filePath);
            goals.RemoveAll(g => g.Id == goalId);
            _storageService.SaveData(filePath, goals);
        }
    }
}
