using System.Windows;
using Goal_Prioritizer.ViewModels;

namespace Goal_Prioritizer.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (e.Property == DataContextProperty && e.NewValue is MainViewModel vm)
            {
                vm.OnOpenAddGoalDialog += ShowAddGoalDialog;
                vm.OnOpenEditGoalDialog += ShowEditGoalDialog;
            }
        }

        private void ShowAddGoalDialog(AddEditGoalViewModel addVm)
        {
            var dialog = new AddEditGoalWindow { DataContext = addVm, Owner = this };
            dialog.ShowDialog();
        }

        private void ShowEditGoalDialog(AddEditGoalViewModel editVm)
        {
            var dialog = new AddEditGoalWindow { DataContext = editVm, Owner = this };
            dialog.ShowDialog();
        }
    }
}
