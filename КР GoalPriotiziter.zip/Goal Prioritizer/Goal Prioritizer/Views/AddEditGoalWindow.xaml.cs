using System.Windows;
using Goal_Prioritizer.ViewModels;

namespace Goal_Prioritizer.Views
{
    public partial class AddEditGoalWindow : Window
    {
        public AddEditGoalWindow()
        {
            InitializeComponent();
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (e.Property == DataContextProperty && e.NewValue is AddEditGoalViewModel vm)
            {
                vm.OnSave += (_) => DialogResult = true;
                vm.OnCancel += () => DialogResult = false;
            }
        }
    }
}
