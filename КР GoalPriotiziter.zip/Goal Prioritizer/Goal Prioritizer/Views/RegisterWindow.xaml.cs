using System.Windows;
using Goal_Prioritizer.ViewModels;

namespace Goal_Prioritizer.Views
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is RegisterViewModel vm)
            {
                vm.ExecuteRegisterWithPasswords(TxtPassword.Password, TxtConfirmPassword.Password);
            }
        }
    }
}
