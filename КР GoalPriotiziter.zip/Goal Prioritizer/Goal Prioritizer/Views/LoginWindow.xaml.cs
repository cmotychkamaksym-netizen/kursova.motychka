using System.Windows;
using Goal_Prioritizer.ViewModels;

namespace Goal_Prioritizer.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginViewModel vm)
            {
                vm.ExecuteLoginWithPassword(TxtPassword.Password);
            }
        }

        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            // У разі необхідності реактивної валідації
        }
    }
}
